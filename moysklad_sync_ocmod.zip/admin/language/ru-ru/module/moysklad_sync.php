<?php

/**
 * @author d_dyuk
 */
// Heading
$_['heading_title'] = 'Синхронизация с МойСклад';

// Text
$_['text_extension'] = 'Расширения';
$_['text_success'] = 'Настройки модуля успешно сохранены.';
$_['text_edit'] = 'Настройки синхронизации с МойСклад';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Отключено';
$_['text_tab_settings'] = 'Настройки';
$_['text_tab_sync'] = 'Синхронизация';
$_['text_tab_products'] = 'Товары';
$_['text_tab_logs'] = 'Логи';
$_['text_placeholder_stage'] = 'Кнопки запускают пошаговые задачи. Импорт категорий, базовых товаров и точных остатков по выбранному складу уже подключен. Изображения будут добавлены отдельным этапом.';
$_['text_action_none'] = 'Ничего не делать';
$_['text_action_disable'] = 'Отключать';
$_['text_action_delete'] = 'Удалять';
$_['text_seo_new_only'] = 'Генерировать только для новых товаров и категорий';
$_['text_log_error_warning'] = 'Ошибки и предупреждения';
$_['text_log_info'] = 'Информационный';
$_['text_log_debug'] = 'Отладочный';
$_['text_incoming_quantity_zero'] = 'Ставить quantity = 0 и статус наличия «Ожидается/Предзаказ»';
$_['text_incoming_quantity_expected'] = 'Ставить количество из заказов поставщикам';
$_['text_incoming_match_separate'] = 'Всегда создавать отдельный товар из заказа поставщику';
$_['text_incoming_match_merge_by_name'] = 'Объединять с товаром в наличии, если совпадает наименование';
$_['text_no_logs'] = 'Логи появятся после запуска задач.';
$_['text_connection_success'] = 'Подключение к МойСклад успешно проверено.';
$_['text_dictionaries_loaded'] = 'Справочники МойСклад успешно загружены.';
$_['text_select_warehouse'] = 'Выберите склад';
$_['text_select_price_type'] = 'Выберите тип цены';
$_['text_current_value'] = 'Текущее значение';
$_['text_loading'] = 'Загрузка...';
$_['text_products_status_title'] = 'Статусы синхронизированных товаров';
$_['text_products_status_help'] = 'Здесь видно, откуда товар попал на сайт: с выбранного склада или из заказа поставщику. Для ожидаемых товаров отображается статус заказа поставщику и ожидаемое количество.';
$_['text_no_products_status'] = 'Товары появятся после импорта.';
$_['text_product_source_stock'] = 'В наличии';
$_['text_product_source_incoming'] = 'Заказ поставщику';
$_['text_product_source_stock_incoming'] = 'В наличии + заказ поставщику';
$_['text_product_source_missing'] = 'Нет на выбранном складе';
$_['text_product_source_unknown'] = 'Неизвестно';
$_['text_product_disabled'] = 'Отключен';
$_['text_incoming_quantity_label'] = 'Ожидается';
$_['text_all'] = 'Все';
$_['text_status_enabled'] = 'Включен';
$_['text_status_disabled'] = 'Отключен';
$_['text_quantity_positive'] = 'Больше 0';
$_['text_quantity_zero'] = '0';
$_['text_expected_positive'] = 'Есть ожидаемое';
$_['text_expected_zero'] = 'Нет ожидаемого';
$_['text_order_asc'] = 'По возрастанию';
$_['text_order_desc'] = 'По убыванию';
$_['text_products_filters_title'] = 'Фильтры и сортировка';
$_['text_products_filters_help'] = 'Фильтры применяются на стороне сервера, поэтому список остается быстрым на большом каталоге.';
$_['text_sort_by_product'] = 'По названию товара';
$_['text_sort_by_article'] = 'По артикулу';
$_['text_sort_by_source'] = 'По источнику';
$_['text_sort_by_quantity'] = 'По фактическому остатку';
$_['text_sort_by_expected'] = 'По ожидаемому количеству';
$_['text_sort_by_stock_status'] = 'По статусу наличия';
$_['text_sort_by_purchase_order'] = 'По заказу поставщику';
$_['text_sort_by_updated'] = 'По дате обновления';
$_['text_sort_presets'] = 'Быстрая сортировка';
$_['text_sort_name_asc'] = 'Название А→Я';
$_['text_sort_name_desc'] = 'Название Я→А';
$_['text_sort_quantity_desc'] = 'Остаток больше→меньше';
$_['text_sort_quantity_asc'] = 'Остаток меньше→больше';
$_['text_sort_expected_desc'] = 'Ожидается больше→меньше';
$_['text_sort_expected_asc'] = 'Ожидается меньше→больше';
$_['text_sort_updated_desc'] = 'Сначала новые';
$_['text_sort_updated_asc'] = 'Сначала старые';
$_['text_summary_shown'] = 'Показано строк';
$_['text_summary_stock'] = 'В наличии';
$_['text_summary_incoming'] = 'Из заказов';
$_['text_summary_expected'] = 'Ожидается всего';

// Entry
$_['entry_status'] = 'Статус модуля';
$_['entry_api_token'] = 'API-токен МойСклад';
$_['entry_warehouse_id'] = 'Склады МойСклад';
$_['entry_price_type_id'] = 'Тип цены';
$_['entry_purchase_orders_enabled'] = 'Учитывать заказы поставщикам';
$_['entry_purchase_order_states'] = 'Статусы заказов поставщикам';
$_['entry_incoming_quantity_mode'] = 'Количество ожидаемых товаров';
$_['entry_incoming_stock_status_id'] = 'Статус наличия для ожидаемых';
$_['entry_incoming_product_match_mode'] = 'Товары из заказов поставщикам';
$_['entry_missing_product_action'] = 'Если товара нет в МойСклад';
$_['entry_missing_category_action'] = 'Если категории нет в МойСклад';
$_['entry_zero_stock_action'] = 'Если остаток товара 0';
$_['entry_category_batch_size'] = 'Батч категорий';
$_['entry_product_batch_size'] = 'Батч товаров';
$_['entry_stock_batch_size'] = 'Батч остатков';
$_['entry_image_batch_size'] = 'Батч изображений';
$_['entry_max_images_per_product'] = 'Макс. изображений на товар за проход';
$_['entry_max_image_bytes'] = 'Макс. размер изображения, байт';
$_['entry_log_level'] = 'Уровень логирования';
$_['entry_seo_mode'] = 'SEO URL';
$_['entry_clear_empty_description'] = 'Очищать описание, если в МойСклад пусто';
$_['entry_product_filter_search'] = 'Поиск';
$_['entry_product_filter_source'] = 'Источник';
$_['entry_product_filter_status'] = 'Статус товара';
$_['entry_product_filter_quantity'] = 'Остаток';
$_['entry_product_filter_expected'] = 'Ожидаемое количество';
$_['entry_product_filter_order_state'] = 'Статус заказа';
$_['entry_product_sort'] = 'Сортировка';
$_['entry_product_order'] = 'Направление';
$_['entry_product_limit'] = 'Показывать';

// Columns
$_['column_product'] = 'Товар';
$_['column_article'] = 'Артикул';
$_['column_sync_source'] = 'Источник / статус';
$_['column_quantity'] = 'Остаток';
$_['column_expected_quantity'] = 'Ожидается от поставщика';
$_['column_stock_status'] = 'Статус наличия';
$_['column_purchase_order'] = 'Заказ поставщику';
$_['column_purchase_order_state'] = 'Статус заказа поставщику';
$_['column_updated'] = 'Обновлено';
$_['column_product_id'] = 'ID';

// Help
$_['help_api_token'] = 'Токен будет сохранен в настройках модуля. После сохранения он не выводится обратно в форму.';
$_['help_warehouse_id'] = 'Нажмите «Загрузить склады, цены и статусы закупок», затем выберите один или несколько складов. Фактический остаток будет суммироваться по выбранным складам.';
$_['help_price_type_id'] = 'Выберите тип цены продажи из МойСклад. Эту цену будем записывать в стандартное поле цены товара ocStore.';
$_['help_purchase_orders_enabled'] = 'Если включено, модуль дополнительно просматривает заказы поставщикам и оставляет на сайте товары, которые еще не приехали на склад, но находятся в выбранных статусах закупки.';
$_['help_purchase_order_states'] = 'Можно выбрать несколько статусов одновременно. Например: ПРЕДЗАКАЗ и ПОПОЛНЕНИЕ СКЛАДА. Сначала нажмите «Загрузить склады и типы цен», чтобы получить статусы из МойСклад.';
$_['help_incoming_quantity_mode'] = 'Безопасный вариант — quantity = 0: товар виден на сайте как ожидаемый, но не считается фактическим складским остатком. В режиме объединения по наименованию эта настройка принудительно работает как quantity = 0: фактический остаток и ожидаемое количество всегда разделяются.';
$_['help_incoming_stock_status_id'] = 'Этот stock status будет назначен товарам, которых нет на складе, но они есть в выбранных заказах поставщикам.';
$_['help_incoming_product_match_mode'] = 'Если включить объединение, модуль будет искать товар с фактическим остатком по нормализованному наименованию и добавлять к нему ожидаемое количество из заказа поставщику, не создавая дубль. Quantity товара при этом не увеличивается: в ocStore остается только фактический остаток, а ожидаемое количество видно отдельной колонкой.';
$_['help_batches'] = 'Для слабого сервера лучше оставлять небольшие значения. Рекомендации: категории 30, товары 20, остатки 50, изображения 3.';
$_['help_images_limits'] = 'Ограничения защищают слабый сервер от слишком тяжелой загрузки картинок. Рекомендуемые значения: 5 изображений на товар, 10485760 байт на файл.';
$_['help_dictionaries'] = 'Сначала введите API-токен. Можно загрузить справочники до сохранения токена.';

// Buttons
$_['button_save'] = 'Сохранить';
$_['button_back'] = 'Назад';
$_['button_import'] = 'Импорт товаров';
$_['button_stock'] = 'Обновить остатки';
$_['button_images'] = 'Загрузить картинки';
$_['button_test_connection'] = 'Проверить подключение';
$_['button_load_dictionaries'] = 'Загрузить склады, цены и статусы закупок';
$_['button_apply_filter'] = 'Применить фильтр';
$_['button_reset_filter'] = 'Сбросить';

// Error
$_['error_permission'] = 'У вас нет прав на изменение модуля синхронизации с МойСклад.';
$_['error_batch_category'] = 'Батч категорий должен быть от 1 до 500.';
$_['error_batch_product'] = 'Батч товаров должен быть от 1 до 200.';
$_['error_batch_stock'] = 'Батч остатков должен быть от 1 до 500.';
$_['error_batch_image'] = 'Батч изображений должен быть от 1 до 50.';
$_['error_max_images_per_product'] = 'Максимум изображений на товар должен быть от 1 до 20.';
$_['error_max_image_bytes'] = 'Максимальный размер изображения должен быть от 1048576 до 31457280 байт.';
$_['error_unexpected'] = 'Непредвиденная ошибка:';

// Task texts
$_['text_task_created'] = 'Задача создана. Запускаю пошаговое выполнение.';
$_['text_task_step_done'] = 'Шаг задачи выполнен.';
$_['text_task_stopped'] = 'Задача остановлена.';
$_['text_task_panel_empty'] = 'Активных задач пока нет.';
$_['text_task_panel_title'] = 'Текущая задача';
$_['text_task_type_import'] = 'Импорт товаров';
$_['text_task_type_stock'] = 'Обновление остатков';
$_['text_task_type_images'] = 'Загрузка изображений';
$_['text_task_status_new'] = 'Создана';
$_['text_task_status_running'] = 'Выполняется';
$_['text_task_status_paused'] = 'На паузе';
$_['text_task_status_finished'] = 'Завершена';
$_['text_task_status_finished_with_errors'] = 'Завершена с ошибками';
$_['text_task_status_failed'] = 'Ошибка';
$_['text_task_status_stopped'] = 'Остановлена';
$_['text_step_init'] = 'Инициализация';
$_['text_step_sync_categories'] = 'Синхронизация категорий';
$_['text_step_rebuild_category_tree'] = 'Построение дерева категорий';
$_['text_step_sync_products'] = 'Синхронизация товаров';
$_['text_step_sync_incoming_products'] = 'Учет заказов поставщикам';
$_['text_step_missing_categories'] = 'Обработка отсутствующих категорий';
$_['text_step_missing_products'] = 'Обработка отсутствующих товаров';
$_['text_step_sync_stock'] = 'Обновление остатков';
$_['text_step_sync_images'] = 'Загрузка изображений';
$_['text_step_finish'] = 'Завершение';
$_['text_logs_latest'] = 'Последние события';
$_['text_counter_processed'] = 'Обработано';
$_['text_counter_created'] = 'Создано';
$_['text_counter_updated'] = 'Обновлено';
$_['text_counter_skipped'] = 'Пропущено';
$_['text_counter_disabled'] = 'Отключено';
$_['text_counter_deleted'] = 'Удалено';
$_['text_counter_errors'] = 'Ошибок';
$_['text_stage3_notice'] = 'Импорт создает категории, выгружает товары выбранного склада с остатком > 0, учитывает выбранные заказы поставщикам как ожидаемые товары и отдельно загружает изображения маленькими пакетами.';

// Task buttons
$_['button_stop_task'] = 'Остановить задачу';
$_['button_refresh_status'] = 'Обновить статус';
$_['button_export_products'] = 'Скачать CSV';

// Task errors
$_['error_no_active_task'] = 'Нет активной задачи.';
$_['error_task_locked'] = 'Задача уже выполняется другим запросом. Повторите через несколько секунд.';
$_['error_task_failed'] = 'Задача завершилась с ошибкой:';
$_['error_module_disabled'] = 'Модуль отключен. Включите его в настройках и сохраните.';
$_['error_api_token_required'] = 'Укажите API-токен МойСклад и сохраните настройки.';
$_['error_warehouse_required'] = 'Выберите склад МойСклад и сохраните настройки.';
$_['error_price_type_required'] = 'Выберите тип цены МойСклад и сохраните настройки.';
$_['error_unknown_ajax_action'] = 'Неизвестное AJAX-действие:';

// Diagnostics / release candidate
$_['text_tab_diagnostics'] = 'Диагностика';
$_['text_diagnostics_title'] = 'Диагностика модуля';
$_['text_diagnostics_help'] = 'Проверяет установку, права, dashboard-виджет, доступность папок и состояние API debug log. Это нужно для релизной проверки и быстрой поддержки на чужом хостинге.';
$_['text_diagnostics_empty'] = 'Нажмите «Обновить диагностику», чтобы проверить состояние модуля.';
$_['text_yes'] = 'Да';
$_['text_no'] = 'Нет';
$_['text_diag_core'] = 'Основные настройки';
$_['text_diag_version'] = 'Версия';
$_['text_diag_module_enabled'] = 'Модуль включен';
$_['text_diag_api_token'] = 'API-токен указан';
$_['text_diag_price_type'] = 'Тип цены выбран';
$_['text_diag_warehouses'] = 'Выбрано складов';
$_['text_diag_purchase_states'] = 'Статусов закупок';
$_['text_diag_dashboard'] = 'Dashboard-виджет';
$_['text_diag_dashboard_extension'] = 'Расширение зарегистрировано';
$_['text_diag_dashboard_status'] = 'Виджет включен';
$_['text_diag_dashboard_width'] = 'Ширина';
$_['text_diag_dashboard_sort'] = 'Сортировка';
$_['text_diag_dashboard_access'] = 'Есть право доступа';
$_['text_diag_permissions'] = 'Права администратора';
$_['text_diag_user_group'] = 'Группа пользователя';
$_['text_diag_module_access'] = 'Доступ к модулю';
$_['text_diag_module_modify'] = 'Право изменения';
$_['text_diag_server'] = 'Сервер и файловая система';
$_['text_diag_image_writable'] = 'Папка image доступна для записи';
$_['text_diag_logs_writable'] = 'Папка storage/logs доступна для записи';
$_['text_diag_extension_dir'] = 'Папка расширения найдена';
$_['text_diag_api_log'] = 'API debug log';
$_['text_diag_api_debug_enabled'] = 'Запись API debug включена';
$_['text_diag_api_log_exists'] = 'Файл существует';
$_['text_diag_api_log_size'] = 'Размер файла';
$_['text_diag_last_task'] = 'Последняя задача';
$_['text_diag_task_type'] = 'Тип';
$_['text_diag_task_status'] = 'Статус';
$_['text_diag_task_errors'] = 'Ошибок';
$_['text_diag_last_error'] = 'Последняя ошибка/лог';
$_['text_api_debug_log_cleared'] = 'API debug log очищен.';
$_['text_api_debug_log_already_empty'] = 'API debug log уже пустой.';
$_['text_api_debug_log_missing'] = 'API debug log еще не создан или недоступен для чтения.';
$_['entry_api_debug_enabled'] = 'API debug log';
$_['help_api_debug_enabled'] = 'Записывать сырые ответы МойСклад в storage/logs/moysklad_sync_api_debug.log. Токен в файл не пишется. Для обычной работы лучше держать выключенным и включать только на время диагностики.';
$_['button_refresh_diagnostics'] = 'Обновить диагностику';
$_['button_download_api_debug_log'] = 'Скачать API debug log';
$_['button_clear_api_debug_log'] = 'Очистить API debug log';
